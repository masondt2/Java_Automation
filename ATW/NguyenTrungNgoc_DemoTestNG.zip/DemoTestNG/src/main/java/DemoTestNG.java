import org.testng.annotations.Test;

public class DemoTestNG {
    @Test
    public void test(){
        System.out.println("Hello, this is a test");
    }
}
