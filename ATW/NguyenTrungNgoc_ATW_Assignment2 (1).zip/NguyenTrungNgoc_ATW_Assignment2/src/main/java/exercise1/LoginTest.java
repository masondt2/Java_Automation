package exercise1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTest {
    @Test
    public void Test1() {
        WebDriver driver = new ChromeDriver();
        driver.navigate().to("https://rawal-admin.themes-coder.net/admin/login?");
        driver.manage().window().maximize();

        //get WebElement
        WebElement user = driver.findElement(By.id("email"));
        WebElement password = driver.findElement(By.id("password"));
        WebElement loginButton = driver.findElement(By.xpath("//button[@type='submit']"));

        //Check WebElement
        Assert.assertTrue(user.isDisplayed(),"User is not displayed");
        Assert.assertTrue(password.isDisplayed(),"Password is not displayed");
        Assert.assertTrue(loginButton.isDisplayed(),"Login button is not displayed");

        driver.quit();
    }
}
