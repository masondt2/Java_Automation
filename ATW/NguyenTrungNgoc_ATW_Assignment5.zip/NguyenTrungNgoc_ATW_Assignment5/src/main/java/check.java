import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class check {
        @Test
        public void One() {
            System.out.println("This is the Test Case number One");
        }

        @Test
        public void Two() {
            System.out.println("This is the Test Case number Two");
        }

        @Test
        public void Three() {
            System.out.println("This is the Test Case number Three");
        }

        @Test
        public void Four(){
            System.out.println("This is the Test Case number Four");
        }
    }
