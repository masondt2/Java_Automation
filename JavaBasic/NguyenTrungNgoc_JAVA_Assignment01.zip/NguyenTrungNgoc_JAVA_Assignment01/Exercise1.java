package NguyenTrungNgoc_JAVA_Assignment01;
/*
Write a Java program to print the sum of two numbers.
Test Data:
74 + 36
Expected Output :
110
 */
public class Exercise1
{
    public static void main(String[] args)
    {
        int x = 74, y = 36, result;
        result = x + y;
        System.out.println(result);
    }
}
