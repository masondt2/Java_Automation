package FinalProject.dao;

import FinalProject.entity.Enrollment;

public interface EnrollmentDao {
    boolean addEnrollment(Enrollment enrollment);


}
